from __future__ import annotations

from typing import Any


def _parse_money(value: Any) -> float | None:
    if value is None:
        return None

    text = (
        str(value)
        .replace("$", "")
        .replace(",", "")
        .strip()
    )

    if text in {"", "N/A", "None", "Unknown"}:
        return None

    multiplier = 1.0

    if text.endswith("B"):
        multiplier = 1_000_000_000
        text = text[:-1]
    elif text.endswith("M"):
        multiplier = 1_000_000
        text = text[:-1]
    elif text.endswith("K"):
        multiplier = 1_000
        text = text[:-1]

    try:
        return float(text) * multiplier
    except ValueError:
        return None


def _statement_values(
    table: list[list[Any]],
    metric: str,
) -> list[float]:
    for row in table[1:]:
        if row and str(row[0]).strip() == metric:
            result = []

            for value in row[1:]:
                parsed = _parse_money(value)

                if parsed is not None:
                    result.append(parsed)

            return result

    return []


def _latest_value(
    table: list[list[Any]],
    metric: str,
) -> float | None:
    values = _statement_values(table, metric)
    return values[0] if values else None


def _growth_rate(
    newest: float | None,
    oldest: float | None,
) -> float | None:
    if newest is None or oldest in {None, 0}:
        return None

    return (newest / oldest - 1) * 100


def _format_money(
    value: float | None,
) -> str:
    if value is None:
        return "N/A"

    absolute = abs(value)

    if absolute >= 1_000_000_000:
        return f"${value / 1_000_000_000:.1f}B"

    if absolute >= 1_000_000:
        return f"${value / 1_000_000:.0f}M"

    if absolute >= 1_000:
        return f"${value / 1_000:.0f}K"

    return f"${value:,.0f}"


def _clean_text(
    value: Any,
    default: str,
) -> str:
    text = str(value or "").strip()

    if text in {
        "",
        "N/A",
        "None",
        "Unknown",
    }:
        return default

    return text


def _concise_business_model(
    company_name: str,
    industry: str,
    company_description: str,
) -> str:
    description = _clean_text(
        company_description,
        "",
    )

    if description:
        sentences = [
            sentence.strip()
            for sentence in description.replace(
                "\n",
                " ",
            ).split(".")
            if sentence.strip()
        ]

        if sentences:
            concise = ". ".join(sentences[:2])

            if len(concise) > 420:
                concise = concise[:417].rsplit(
                    " ",
                    1,
                )[0] + "..."

            return concise.rstrip(".") + "."

    return (
        f"{company_name} operates in {industry.lower()}, "
        "combining internal development activities with "
        "commercial, research, or strategic partnership "
        "opportunities."
    )


def build_executive_summary(
    company_name: str,
    ticker: str,
    exchange: str,
    industry: str,
    company_description: str,
    income_statement: list[list[Any]],
    balance_sheet: list[list[Any]],
    cash_flow: list[list[Any]],
    estimated_runway: str,
    latest_filing: str,
) -> dict[str, Any]:
    revenues = _statement_values(
        income_statement,
        "Revenue",
    )
    rd_values = _statement_values(
        income_statement,
        "R&D Expense",
    )

    revenue_growth = (
        _growth_rate(
            revenues[0],
            revenues[-1],
        )
        if len(revenues) >= 2
        else None
    )

    rd_growth = (
        _growth_rate(
            rd_values[0],
            rd_values[-1],
        )
        if len(rd_values) >= 2
        else None
    )

    latest_revenue = (
        revenues[0]
        if revenues
        else None
    )

    latest_rd = (
        rd_values[0]
        if rd_values
        else None
    )

    cash = _latest_value(
        balance_sheet,
        "Cash & Equivalents",
    )
    debt = _latest_value(
        balance_sheet,
        "Total Debt",
    )
    free_cash_flow = _latest_value(
        cash_flow,
        "Free Cash Flow",
    )
    net_income = _latest_value(
        income_statement,
        "Net Income",
    )

    net_cash = (
        cash - debt
        if cash is not None
        and debt is not None
        else None
    )

    financial_points: list[str] = []
    investment_highlights: list[str] = []
    key_risks: list[str] = []
    catalysts: list[str] = []

    if cash is not None:
        investment_highlights.append(
            (
                f"Cash and equivalents of "
                f"{_format_money(cash)} support ongoing "
                "operations and development activity."
            )
        )

    if net_cash is not None and net_cash > 0:
        investment_highlights.append(
            (
                f"Net cash of approximately "
                f"{_format_money(net_cash)} provides "
                "balance-sheet flexibility."
            )
        )

    if revenue_growth is not None:
        direction = (
            "increased"
            if revenue_growth >= 0
            else "declined"
        )

        financial_points.append(
            (
                f"Revenue {direction} approximately "
                f"{abs(revenue_growth):.0f}% across the "
                "available annual periods."
            )
        )

        if revenue_growth > 0:
            investment_highlights.append(
                (
                    f"Revenue expanded approximately "
                    f"{revenue_growth:.0f}% across the "
                    "available annual periods."
                )
            )

    if latest_revenue is not None:
        financial_points.append(
            (
                f"Latest reported annual revenue was "
                f"approximately "
                f"{_format_money(latest_revenue)}."
            )
        )

    if rd_growth is not None:
        direction = (
            "increased"
            if rd_growth >= 0
            else "declined"
        )

        financial_points.append(
            (
                f"R&D spending {direction} approximately "
                f"{abs(rd_growth):.0f}% across the "
                "available annual periods."
            )
        )

    if latest_rd is not None:
        investment_highlights.append(
            (
                f"R&D investment of approximately "
                f"{_format_money(latest_rd)} reflects "
                "continued platform or pipeline development."
            )
        )

    if free_cash_flow is not None:
        if free_cash_flow < 0:
            financial_points.append(
                (
                    f"Annual free cash flow was negative "
                    f"at approximately "
                    f"{_format_money(abs(free_cash_flow))}."
                )
            )

            key_risks.append(
                (
                    "Continued negative free cash flow may "
                    "increase future financing requirements."
                )
            )
        else:
            financial_points.append(
                (
                    f"Annual free cash flow was positive "
                    f"at approximately "
                    f"{_format_money(free_cash_flow)}."
                )
            )

    if net_income is not None and net_income < 0:
        key_risks.append(
            (
                "Continued net losses may delay financial "
                "self-sufficiency."
            )
        )

    if debt is not None and cash is not None:
        if debt > cash:
            key_risks.append(
                (
                    "Debt exceeds reported cash and may "
                    "reduce financial flexibility."
                )
            )

    if estimated_runway not in {
        "",
        "N/A",
        "None",
    }:
        financial_points.append(
            (
                f"Estimated funding runway is "
                f"{estimated_runway}."
            )
        )

    industry_lower = industry.lower()

    if any(
        term in industry_lower
        for term in [
            "biotech",
            "biotechnology",
            "pharmaceutical",
            "drug",
            "therapeutic",
        ]
    ):
        key_risks.extend(
            [
                (
                    "Clinical or development setbacks could "
                    "materially reduce program value."
                ),
                (
                    "Long development and commercialization "
                    "timelines create execution uncertainty."
                ),
            ]
        )

        catalysts.extend(
            [
                "Clinical data and pipeline-development updates.",
                (
                    "Regulatory, enrollment, or program-"
                    "advancement milestones."
                ),
            ]
        )
    else:
        key_risks.append(
            (
                "Execution delays could weaken operating "
                "performance and competitive positioning."
            )
        )

        catalysts.append(
            (
                "Product, platform, or commercial execution "
                "updates."
            )
        )

    catalysts.extend(
        [
            (
                "New strategic partnership or milestone "
                "announcements."
            ),
            (
                "Quarterly financial and liquidity updates."
            ),
        ]
    )

    if latest_filing not in {
        "",
        "N/A",
        "No recent filing available",
    }:
        catalysts.append(
            f"Review of the latest disclosed filing: {latest_filing}."
        )

    default_highlights = [
        (
            "The company operates in a market where technical "
            "execution and differentiated capabilities may "
            "support long-term value creation."
        ),
        (
            "Strategic partnerships may expand development, "
            "validation, or commercialization opportunities."
        ),
        (
            "Successful execution of internal programs could "
            "strengthen the company’s operating position."
        ),
    ]

    for item in default_highlights:
        if len(investment_highlights) >= 4:
            break

        investment_highlights.append(item)

    default_risks = [
        (
            "Failure to convert technical capabilities into "
            "durable commercial revenue remains a central risk."
        ),
        (
            "Competitive pressure may reduce differentiation "
            "or increase required investment."
        ),
        (
            "Future capital needs may result in shareholder "
            "dilution."
        ),
    ]

    for item in default_risks:
        if len(key_risks) >= 4:
            break

        key_risks.append(item)

    business_model = _concise_business_model(
        company_name=company_name,
        industry=industry,
        company_description=company_description,
    )

    company_identity = (
        f"{company_name} "
        f"({exchange}: {ticker})"
        if exchange not in {
            "",
            "N/A",
            "Unknown",
        }
        else f"{company_name} ({ticker})"
    )

    overview = (
        f"{company_identity} operates in {industry}. "
        f"{business_model}"
    )

    # Preserve the legacy keys used by the current PDF
    # renderer while adding the new commercial structure.
    return {
        "title": "Executive Summary",
        "company": company_identity,
        "company_name": company_name,
        "ticker": ticker,
        "exchange": exchange,
        "industry": industry,
        "business_model": business_model,
        "investment_highlights": investment_highlights[:4],
        "key_risks": key_risks[:4],
        "key_catalysts": catalysts[:4],
        "financial_snapshot": {
            "Revenue": _format_money(
                latest_revenue
            ),
            "Cash": _format_money(cash),
            "Debt": _format_money(debt),
            "Net Income": _format_money(
                net_income
            ),
            "Free Cash Flow": _format_money(
                free_cash_flow
            ),
            "Estimated Runway": estimated_runway,
        },
        "financial_analysis": " ".join(
            financial_points
        ),
        "latest_filing": latest_filing,
        "overview": overview,
        "bull_case": investment_highlights[:4],
        "bear_case": key_risks[:4],
    }

