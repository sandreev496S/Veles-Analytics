from reportlab.platypus import Table

from services.pdf.callouts import (
    analyst_callout,
    three_column_callouts,
)
from services.pdf.theme import (
    VELES_PDF_THEME,
    build_pdf_styles,
)


def test_three_column_callouts_fit_content_width():
    styles = build_pdf_styles()

    component = three_column_callouts(
        ("Bull Case", "One\nTwo\nThree", "positive"),
        ("Bear Case", "One\nTwo\nThree", "negative"),
        ("Catalysts", "One\nTwo\nThree", "insight"),
        styles,
    )

    assert isinstance(component, Table)

    total_width = sum(component._argW)

    assert total_width <= VELES_PDF_THEME.content_width + 1


def test_full_width_callout_uses_report_width():
    styles = build_pdf_styles()

    component = analyst_callout(
        "Financial Assessment",
        "Revenue increased while cash burn remained elevated.",
        styles,
        width=VELES_PDF_THEME.content_width,
    )

    assert isinstance(component, Table)
    assert component._argW[0] == VELES_PDF_THEME.content_width
