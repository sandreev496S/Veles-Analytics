from __future__ import annotations

from typing import Any

from services.crm.models import CRMProject
from services.reports.equity_report_assembler import (
    assemble_equity_report,
)
from services.reports.project.context import (
    ProjectReportConfig,
    build_project_report_config,
)


def _apply_project_context(
    report: Any,
    config: ProjectReportConfig,
) -> Any:
    """
    Attach CRM project context to the assembled report.

    ReportDocument may be a dataclass or a compatible
    object. Attributes are set only when possible.
    """
    context_payload = config.to_dict()

    assignments = {
        "project_id": (
            config.project_id
        ),
        "client_name": (
            config.client_name
        ),
        "package": config.package,
        "project_objective": (
            config.primary_objective
        ),
        "intended_audience": (
            config.intended_audience
        ),
        "requested_focus_areas": (
            config.requested_focus_areas
        ),
        "project_context": (
            context_payload
        ),
    }

    for attribute, value in assignments.items():
        try:
            setattr(
                report,
                attribute,
                value,
            )
        except Exception:
            continue

    if hasattr(report, "metadata"):
        metadata = getattr(
            report,
            "metadata",
            None,
        )

        if isinstance(metadata, dict):
            metadata[
                "project_context"
            ] = context_payload

    return report


def assemble_project_report(
    config: ProjectReportConfig,
) -> Any:
    if not config.ticker:
        raise ValueError(
            "A ticker is required for the current "
            "public-company report pipeline."
        )

    report = assemble_equity_report(
        config.ticker
    )

    return _apply_project_context(
        report,
        config,
    )


def assemble_report_for_project(
    project: CRMProject,
) -> Any:
    config = build_project_report_config(
        project
    )

    return assemble_project_report(
        config
    )
