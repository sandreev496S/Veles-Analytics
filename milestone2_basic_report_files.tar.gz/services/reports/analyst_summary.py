from __future__ import annotations

from typing import Any


def _parse_money(value: Any) -> float | None:
    if value is None:
        return None

    text = (
        str(value)
        .replace("$", "")
        .replace(",", "")
        .strip()
    )

    if text in {"", "N/A", "None", "Unknown"}:
        return None

    multiplier = 1.0

    if text.endswith("B"):
        multiplier = 1_000_000_000
        text = text[:-1]
    elif text.endswith("M"):
        multiplier = 1_000_000
        text = text[:-1]
    elif text.endswith("K"):
        multiplier = 1_000
        text = text[:-1]

    try:
        return float(text) * multiplier
    except ValueError:
        return None


def _statement_values(
    table: list[list[Any]],
    metric: str,
) -> list[float]:
    for row in table[1:]:
        if row and str(row[0]).strip() == metric:
            result = []

            for value in row[1:]:
                parsed = _parse_money(value)

                if parsed is not None:
                    result.append(parsed)

            return result

    return []


def _latest_value(
    table: list[list[Any]],
    metric: str,
) -> float | None:
    values = _statement_values(table, metric)
    return values[0] if values else None


def _growth_rate(
    newest: float | None,
    oldest: float | None,
) -> float | None:
    if newest is None or oldest in {None, 0}:
        return None

    return (newest / oldest - 1) * 100


def build_executive_summary(
    company_name: str,
    industry: str,
    income_statement: list[list[Any]],
    balance_sheet: list[list[Any]],
    cash_flow: list[list[Any]],
    estimated_runway: str,
    latest_filing: str,
) -> dict[str, Any]:
    revenues = _statement_values(
        income_statement,
        "Revenue",
    )
    rd_values = _statement_values(
        income_statement,
        "R&D Expense",
    )

    revenue_growth = (
        _growth_rate(revenues[0], revenues[-1])
        if len(revenues) >= 2
        else None
    )
    rd_growth = (
        _growth_rate(rd_values[0], rd_values[-1])
        if len(rd_values) >= 2
        else None
    )

    cash = _latest_value(
        balance_sheet,
        "Cash & Equivalents",
    )
    debt = _latest_value(
        balance_sheet,
        "Total Debt",
    )
    free_cash_flow = _latest_value(
        cash_flow,
        "Free Cash Flow",
    )

    net_cash = (
        cash - debt
        if cash is not None and debt is not None
        else None
    )

    financial_analysis = []

    if revenue_growth is not None:
        financial_analysis.append(
            (
                f"Revenue increased approximately {revenue_growth:.0f}% "
                "across the available annual periods."
            )
        )

    if rd_growth is not None:
        financial_analysis.append(
            (
                f"R&D spending increased approximately {rd_growth:.0f}% "
                "over the same period, indicating rising investment intensity."
            )
        )

    if net_cash is not None:
        financial_analysis.append(
            (
                f"The balance sheet holds approximately "
                f"${net_cash / 1_000_000:.0f}M of net cash."
            )
        )

    if free_cash_flow is not None and free_cash_flow < 0:
        financial_analysis.append(
            (
                f"Annual free cash flow remains negative at approximately "
                f"${abs(free_cash_flow) / 1_000_000:.0f}M."
            )
        )

    financial_analysis.append(
        f"Estimated funding runway is approximately {estimated_runway}."
    )

    return {
        "overview": (
            f"{company_name} is a public {industry.lower()} company whose "
            "investment case depends on technical execution, pipeline "
            "validation, partnership economics, and access to sufficient "
            "capital to fund development."
        ),
        "financial_analysis": " ".join(financial_analysis),
        "bull_case": [
            "Successful progression of internal development programs.",
            "Expansion or monetization of strategic partnerships.",
            "Improved validation of the underlying technology platform.",
        ],
        "bear_case": [
            "Clinical or development setbacks.",
            "Sustained cash burn requiring additional financing.",
            "Inability to convert platform investment into durable revenue.",
        ],
        "key_catalysts": [
            "Clinical data and pipeline-development updates.",
            "New partnership or milestone announcements.",
            "Quarterly financial and liquidity updates.",
        ],
        "latest_filing": latest_filing,
    }
